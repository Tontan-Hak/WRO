# ROAD-CLEANER-ROBOT

## Report 
- [ROAD CLEANER ROBOT REPORT](https://drive.google.com/file/d/1nsHXy8Sw0PvDNHwyt2eP0yfL3b_efRcW/view?usp=sharing)
  
## Video
- [Video](https://www.youtube.com/watch?v=-0kvA0ml9Zk)

## Code
- [Project Code (Java)](https://github.com/SaoSovannroth/WRO_ROAD-CLEANER-ROBOT/blob/main/Project%20Code)
- [Project Block Code (pdf)](https://drive.google.com/file/d/1BjMLO94BjKCHE6sqgelKWZGByBcQfjPN/view?usp=sharing)

## Picture
![photo_2024-09-09_16-31-31](https://github.com/user-attachments/assets/98bc3f32-a090-4a8f-8bd4-5dd2ca52eb70)
